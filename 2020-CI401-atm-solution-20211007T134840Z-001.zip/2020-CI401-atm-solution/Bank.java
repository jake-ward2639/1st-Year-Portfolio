import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;

// Bank class - simple implementation of a bank, with a list of bank accounts, an
// a current account that we are logged in to. 

public class Bank
{
    // Instance variables containing the bank information
    int maxAccounts = 10;       // maximum number of accounts the bank can hold
    int numAccounts = 0;        // the number of accounts currently in the bank
    BankAccount[] accounts = new BankAccount[maxAccounts];  // array to hold the bank accounts
    BankAccount account = null; // currently logged in acccount ('null' if no-one is logged in)
    
    //initilising arraylist mini statement
    ArrayList<String> MiniStatement = new ArrayList<String>();
    
    // Constructor method - this provides a couple of example bank accounts to work with
    public Bank()
    {
        Debug.trace( "Bank::<constructor>"); 

        
    }

    // a method to create new BankAccounts - this is known as a 'factory method' and is a more
    // flexible way to do it than just using the 'new' keyword directly.
    /**
     * Method used to create BankAccount objects using the parameters input and return them to its respective addbankaccount method
     */
    public BankAccount makeBankAccount(int accNumber, int accPasswd, int balance) 
    {
        return new BankAccount(accNumber, accPasswd, balance);
    }
    /**
     * A method used to create OverdraftAccount objects using the parameters input and return them to its respective addbankaccount method. 
     * method overloading used here 
     * so the method change bank account has seperate functions depending on the amount of parameters its fed, 
     */
    public BankAccount makeBankAccount(int accNumber, int accPasswd, int balance, int overdraft) 
    {
        return new ODBankAccount(accNumber, accPasswd, balance, overdraft);
    }
    
    // a method to add a new bank account to the bank - it returns true if it succeeds
    // or false if it fails (because the bank is 'full')
    /**
     * takes the account objects from method overloads of the same name and saves them to the accounts array if there is enough space.
     * if there is not enough space it will return false and display an error message in the terminal
     */
    public boolean addBankAccount(BankAccount a)
    {
        if (numAccounts < maxAccounts) {
            accounts[numAccounts] = a;
            numAccounts++ ;
            Debug.trace( "Bank::addBankAccount: Account creation successful");
            return true;
        } else {
            Debug.trace( "Bank::addBankAccount: can't add bank account - too many accounts"); 
            return false;
        }                
    }
    
    /**
     * Method overload of addBankAccount (meaning the same method name can accept different parameter), 
     * this will take the parameters input and call makebankaccount which will transform them into the properties of an object using the bankaccount class
     * This object is then returned to the original addBankAccount
     */
    public boolean addBankAccount(int accNumber, int accPasswd, int balance)
    {
        Debug.trace( "Bank::addBankAccount: adding " + 
                         accNumber +" "+ accPasswd +" �"+ balance);
        return addBankAccount(makeBankAccount(accNumber, accPasswd, balance));        
    } 
    
    /**
     * Another method overload of addBankAccount to account for and use the Overdraft account class
     * , other than that it serves the same purpose
     */
    public boolean addBankAccount(int accNumber, int accPasswd, int balance, int overdraft)
    {
        Debug.trace( "Bank::addBankAccount: adding " + 
                         accNumber +" "+ accPasswd +" �"+ balance +" �"+ overdraft);
        return addBankAccount(makeBankAccount(accNumber, accPasswd, balance, overdraft));
    } 
    
    /**
     * Searches accounts for current accnumber and change its password to number (the current number being input), its void and returns nothing however the trace statement prints what happened to the terminal
     */
    public void changeBankAccountPasswd(int CHGaccNumber, int CHGaccPasswd, int NEWaccPasswd)
    {
        for (BankAccount b: accounts) {
            if (b == null)
            {                
            }
            else if (b.accNumber == CHGaccNumber && b.accPasswd == CHGaccPasswd) {
                 b.accPasswd = NEWaccPasswd;
                 Debug.trace( "Bank::login: passwd changed = " + NEWaccPasswd);
                 //change this code to limit password and if not in limit, initilise
            }
        }        
    }   
    
    // Check whether the current saved account and password correspond to 
    // an actual bank account, and if so login to it (by setting 'account' to it)
    // and return true. Otherwise, reset the account to null and return false
    /**
     * The login method loops through all accounts in the accounts array comparing the username and passwords
     * If the username and password are correct it logs into that by returning true to the login method that called it and saves the correct account number under "account"
     * If either is incorrect then it will return false
     * 
     * Error Description (Solved):
     * the login method present in the skeletal code was not functioning as intendend
     * i found that it was not returning false when executed and no accounts were found
     * however it successfully returned true
     * 
     * i found that by adding and else statement to the account loop returning false that it would only execute the loop once
     * this is because any bool returned would stop executing the method
     * 
     * the soloution was adding a section that detected if the current account being looked at was null
     * what was happening was when it got to a null account then the code would break thus it would never execute the line of code to return false
     */
    public boolean login(int newAccNumber, int newAccPasswd) 
    { 
        Debug.trace( "Bank::login: accNumber = " + newAccNumber);       
        logout(); // logout of any previous account
        
        
        // search the array to find a bank account with matching account and password.
        // If you find it, store it in the variable currentAccount and return true.
        // If you don't find it, reset everything and return false
        

        for (BankAccount b: accounts) {
            
            if (b == null)
            {
                return false;
            }
            else if (b.accNumber == newAccNumber && b.accPasswd == newAccPasswd) {
                // found the right account
                Debug.trace( "Bank::login: logged in, accNumber = " + newAccNumber ); 
                account = b;                 
                return true;
                
            }  
            
            else
            {
                Debug.trace( "Bank::login: nothing found" );
            }
             
        }    
        

         account = null;
         return false;
    }

    // Reset the bank to a 'logged out' state
    /**
     * set current account to null, and wipe current ministatement
     */
    public void logout() 
    {
        if (loggedIn())
        {
            Debug.trace( "Bank::logout: logging out, accNumber = " + account.accNumber);
            account = null;
            MiniStatementClear();
        }
    }
    
    // test whether the bank is logged in to an account or not
    /**
     * If you are logged in return true, if not return false. This works by checking if account is == to null
     * When successfully logged in account will be equal to the account number so if not logged it itll equal null
     */
    public boolean loggedIn()
    {
        if (account == null)
        {
            return false;
        } else {
            return true;
        }
    }   
    
    // try to deposit money into the account (by calling the deposit method on the 
    // BankAccount object)
    /**
     * call method to deposit amount in bank account, add amount in string to current ministatement and save it to a file of transactions 
     */
    public boolean deposit(int amount) 
    {
        if (loggedIn()) {
            try {  
                FileWriter myWriter = new FileWriter("Transactions.txt", true);
                myWriter.write(String.valueOf(amount) + "\n");
                myWriter.close();
            } catch (IOException WriteAttempt) {
                Debug.trace("Bank::Failed to write to file ");
            } 
            MiniStatement.add(String.valueOf(amount));
            return account.deposit(amount);            
        } else {
            return false;
        }
    }
    
    // try to withdraw money into the account (by calling the withdraw method on the 
    // BankAccount object)
    /**
     * call method to withdraw amount from bank account, add amount in string to current ministatement and save it to a file of transactions 
     */
    public boolean withdraw(int amount) 
    {
        if (loggedIn()) {
            try {  
                FileWriter myWriter = new FileWriter("Transactions.txt", true);
                myWriter.write(String.valueOf(amount * -1) + "\n");
                myWriter.close();
            } catch (IOException WriteAttempt) {
                Debug.trace("Bank::Failed to write to file ");
            } 
            MiniStatement.add(String.valueOf(amount * -1));
            return account.withdraw(amount);   
        } else {
            return false;
        }
    }
    
    // get the account balance (by calling the balance method on the 
    // BankAccount object)
    /**
     * call method in bankaccount to display balence of account
     */
    public int getBalance() 
    {
        if (loggedIn()) {
            return account.getBalance();   
        } else {
            return -1; // use -1 as an indicator of an error
        }
    }
    
    //this method is to return all the current transactions made to the process in the model class
    //everytime a transaction is made it is added to the arraylist
    //it is initisilised at the top of the class
    /**
     * if the current ministatement arraylist is empty return "No Transactions Have Been Made", if it isnt then print to display2 the entire ministatment
     */
    public String MiniStatementDisplay() 
    {
        String CurrentMiniStatement = "";
        if (MiniStatement.isEmpty())
        {
            return "No Transactions Have Been Made";
        }
        else
        {
            for (int i = 0; i < MiniStatement.size(); i++)
            {
                CurrentMiniStatement = CurrentMiniStatement + MiniStatement.get(i) + "\n";
            }            
            return CurrentMiniStatement;
        }        
    }
    
    //method used to clear the current history of the user
    //this is a public method so it can be called by initilise in the model class
    /**
     * clear ministatement
     */
    public void MiniStatementClear() 
    {
        MiniStatement.clear();
    }
}