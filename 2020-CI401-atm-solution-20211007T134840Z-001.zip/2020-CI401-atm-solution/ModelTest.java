

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class ModelTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ModelTest
{
    /**
     * Default constructor for test class ModelTest
     */
    public ModelTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {

    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    @Test
    public void Setup_Accounts()
    {
                Bank b = new Bank();
        b.addBankAccount(10001, 11111, 100);
        b.addBankAccount(10002, 22222, 50);
        b.addBankAccount(10003, 33333, 220);
        b.addBankAccount(10004, 44444, 10, 200);
    }
}
