
//the OverDraftBantAccount class uses inheritence to create a different type of account
//method overloading is in the bank to call this so the same method name can be used with different parameters to use the seperate class 
public class ODBankAccount extends BankAccount
{    
    public int overdraft = 0;

    
    public ODBankAccount()
    {
        
    }

    
    public ODBankAccount(int a, int p, int b, int o)
    {
        accNumber = a;
        accPasswd = p;
        balance = b;
        overdraft = o;
    }
}
